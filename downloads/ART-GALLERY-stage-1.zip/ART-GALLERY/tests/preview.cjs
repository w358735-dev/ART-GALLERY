// Verify the self-contained HTML. The cloud browser blocks file:// by policy.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const previewURL = process.env.PREVIEW_URL || 'http://127.0.0.1:8000/preview.html';

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const errors = [];
  try {
    for (const width of [1440, 390]) {
      const page = await browser.newPage({ viewport: { width, height: 900 }, reducedMotion: 'reduce' });
      page.on('pageerror', error => errors.push(error.message));
      page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
      page.on('request', request => { if (/^https?:/.test(request.url()) && request.url() !== previewURL) errors.push(`Unexpected request: ${request.url()}`); });
      await page.goto(previewURL);
      assert.equal(await page.locator('.art-stage').count(), 8);
      await page.locator('#enter-gallery').click();
      assert.equal(await page.evaluate(() => location.hash), '#exhibition');
      for (let index = 0; index < 8; index++) {
        const stage = page.locator('.art-stage').nth(index);
        await stage.locator('.painting-button').click();
        await page.locator('#dialog-image').evaluate(image => image.decode());
        assert.match(await page.locator('#dialog-image').getAttribute('src'), /^data:image\/svg\+xml;base64,/);
        assert.equal(await page.locator('#dialog-title').textContent(), await stage.locator('h3').textContent());
        await page.locator('.purchase-button').click();
        assert.equal(await page.locator('#purchase-message').isVisible(), true);
        await page.keyboard.press('Escape');
      }
      assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
      assert.equal(await page.locator('link[rel=stylesheet], script[src]').count(), 0);
      await page.close();
      console.log(`PASS: standalone preview at ${width}px; all 8 artworks, entrance, purchase and Escape`);
    }
    assert.deepEqual(errors, []);
    console.log('PASS: no browser errors or additional HTTP requests; CSS, JS and SVG embedded');
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
