/* Local smoke tests: node tests/browser.cjs
   Requires Playwright (test tooling only) and a server on 127.0.0.1:8000. */
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
(async () => {
  fs.mkdirSync('artifacts', { recursive: true });
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const results = [];
  const errors = [];
  const badResponses = [];
  const external = [];
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', msg => { if (msg.type() === 'error') errors.push(msg.text()); });
  page.on('response', r => { if (r.status() >= 400) badResponses.push(`${r.status()} ${r.url()}`); });
  page.on('request', r => { if (!r.url().startsWith('http://127.0.0.1:8000/')) external.push(r.url()); });
  const pass = (name, details) => results.push({ name, result: 'PASS', details });
  try {
    await page.goto('http://127.0.0.1:8000/', { waitUntil: 'networkidle' });
    assert.equal(await page.title(), 'Маленький музей — большого таланта');
    assert.equal(await page.locator('.art-stage').count(), 8);
    pass('1. Page opens and renders 8 catalogue entries');
    await page.screenshot({ path: 'artifacts/desktop-entrance.png', fullPage: false });
    await page.locator('#enter-gallery').click();
    await page.waitForFunction(() => location.hash === '#exhibition' && Math.abs(document.querySelector('#exhibition').getBoundingClientRect().top - 100) < 5);
    assert.equal(await page.evaluate(() => document.activeElement.id), 'exhibition');
    pass('2. Entrance button scrolls to exhibition and transfers keyboard focus');
    const catalogue = await page.evaluate(() => window.ARTWORKS);
    for (let i = 0; i < 8; i++) {
      const stage = page.locator('.art-stage').nth(i);
      await stage.scrollIntoViewIfNeeded();
      await stage.locator('img').evaluate(img => img.decode());
      assert.ok(await stage.locator('img').evaluate(img => img.complete && img.naturalWidth > 0));
      await stage.locator('.painting-button').click();
      await page.locator('#art-dialog').waitFor({ state: 'visible' });
      assert.equal(await page.locator('#dialog-title').textContent(), catalogue[i].title);
      for (const key of ['medium', 'size', 'status', 'story']) {
        assert.equal(await page.locator(`#dialog-${key}`).textContent(), catalogue[i][key]);
      }
      await page.locator('#dialog-image').evaluate(img => img.decode());
      assert.equal(await page.locator('#dialog-image').getAttribute('src'), catalogue[i].image);
      assert.equal(await page.locator('#dialog-image').getAttribute('alt'), catalogue[i].alt);
      if (i === 0) {
        const requestCount = external.length;
        await page.locator('.purchase-button').click();
        assert.equal(await page.locator('#purchase-message').isVisible(), true);
        assert.match(await page.locator('#purchase-message').textContent(), /Данные не собираются/);
        assert.equal(external.length, requestCount);
        await page.screenshot({ path: 'artifacts/desktop-dialog.png' });
        await page.keyboard.press('ArrowRight');
        assert.equal(await page.locator('#dialog-title').textContent(), catalogue[1].title);
        assert.equal(await page.locator('#purchase-message').isVisible(), false);
        await page.locator('.previous-art').click();
        assert.equal(await page.locator('#dialog-title').textContent(), catalogue[0].title);
        await page.keyboard.press('ArrowLeft');
        assert.equal(await page.locator('#dialog-title').textContent(), catalogue[7].title);
        // Native modal must retain focus across repeated Tab presses.
        for (let n = 0; n < 12; n++) {
          await page.keyboard.press('Tab');
          assert.equal(await page.evaluate(() => document.activeElement === document.body || document.activeElement.closest('dialog') !== null), true);
        }
      }
      await page.keyboard.press('Escape');
      assert.equal(await page.locator('#art-dialog').isVisible(), false);
      assert.equal(await stage.locator('.painting-button').evaluate(el => el === document.activeElement), true);
    }
    pass('3, 5, 6. All 8 images decode, open large and match catalogue metadata');
    pass('7. Purchase shows demo-only message; no external request; message resets');
    pass('Keyboard: modal focus containment, Escape, focus return, arrows, wrapping and previous button');
    await page.locator('.art-navigation a').nth(3).click();
    await page.waitForFunction(() => location.hash === '#work-garden');
    await page.waitForTimeout(900);
    assert.equal(await page.locator('.art-navigation a[aria-current=true]').textContent(), '04');
    pass('Numbered exhibition navigation');
    await page.locator('.art-stage').first().evaluate(el => window.scrollTo({top: scrollY + el.getBoundingClientRect().top - 500, behavior: 'instant'}));
    await page.waitForTimeout(800);
    const transformBefore = await page.locator('.painting-wrap').first().evaluate(el => getComputedStyle(el).transform);
    const timing = await page.evaluate(async () => {
      const frames = [];
      let previous = performance.now();
      const start = scrollY;
      for (let i = 0; i < 90; i++) {
        await new Promise(requestAnimationFrame);
        const now = performance.now(); frames.push(now - previous); previous = now;
        window.scrollTo({ top: start + i * 7, behavior: 'instant' });
      }
      return { frames: frames.length, maxMs: Math.max(...frames), meanMs: frames.reduce((a,b) => a+b, 0) / frames.length, over50ms: frames.filter(n => n > 50).length };
    });
    const transformAfter = await page.locator('.painting-wrap').first().evaluate(el => getComputedStyle(el).transform);
    assert.notEqual(transformBefore, transformAfter);
    assert.ok(timing.maxMs < 150, `Unexpected frame stall: ${JSON.stringify(timing)}`);
    pass('4. Scroll changes perspective transforms; local 90-frame sample', timing);
    await page.locator('.art-stage').first().evaluate(el => window.scrollTo({top: scrollY + el.getBoundingClientRect().top + 100, behavior: 'instant'}));
    await page.waitForTimeout(100);
    await page.screenshot({ path: 'artifacts/desktop-exhibition.png' });
    await page.locator('.motion-toggle').scrollIntoViewIfNeeded();
    await page.locator('.motion-toggle').click();
    assert.equal(await page.locator('html').getAttribute('class'), 'motion-reduced');
    assert.equal(await page.locator('.painting-wrap').first().evaluate(el => getComputedStyle(el).transform), 'none');
    pass('Manual reduced-motion toggle');
    for (const width of [320, 390, 768, 1440]) {
      await page.setViewportSize({ width, height: width < 700 ? 844 : 1000 });
      for (const target of ['#entrance', '#work-light', '#work-garden', '#artist']) {
        await page.locator(target).scrollIntoViewIfNeeded();
        assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), `Horizontal overflow: ${width} ${target}`);
      }
      await page.locator('[data-art="3"]').last().click();
      await page.locator('#dialog-image').evaluate(img => img.decode());
      assert.ok(await page.locator('#art-dialog').evaluate(el => el.scrollWidth <= el.clientWidth), `Modal overflow at ${width}`);
      await page.locator('.purchase-button').click();
      await page.locator('#purchase-message').scrollIntoViewIfNeeded();
      assert.equal(await page.locator('#purchase-message').isVisible(), true);
      if (width === 390) await page.screenshot({ path: 'artifacts/mobile-dialog.png' });
      await page.locator('.close-dialog').click();
    }
    await page.setViewportSize({ width: 390, height: 844 });
    await page.evaluate(() => window.scrollTo({top: 0, behavior: 'instant'}));
    await page.screenshot({ path: 'artifacts/mobile-entrance.png' });
    pass('8. No horizontal overflow at 320 / 390 / 768 / 1440 px; modal and purchase usable');
    const reduced = await browser.newPage({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
    reduced.on('pageerror', e => errors.push(e.message));
    await reduced.goto('http://127.0.0.1:8000/', { waitUntil: 'networkidle' });
    assert.equal(await reduced.locator('.motion-toggle').getAttribute('aria-pressed'), 'true');
    assert.equal(await reduced.locator('.motion-toggle').isDisabled(), true);
    assert.equal(await reduced.locator('html').evaluate(el => getComputedStyle(el).scrollBehavior), 'auto');
    assert.equal(await reduced.locator('.painting-wrap').first().evaluate(el => getComputedStyle(el).transform), 'none');
    await reduced.locator('#enter-gallery').click();
    await reduced.locator('.art-stage').first().locator('.painting-button').click();
    assert.equal(await reduced.locator('#dialog-title').textContent(), catalogue[0].title);
    await reduced.keyboard.press('Escape');
    await reduced.screenshot({ path: 'artifacts/mobile-reduced-motion.png' });
    pass('9. System prefers-reduced-motion: no perspective or smooth scroll; gallery and modal usable');
    const keyboard = await browser.newPage();
    await keyboard.goto('http://127.0.0.1:8000/');
    await keyboard.keyboard.press('Tab');
    assert.equal(await keyboard.locator('.skip-link').evaluate(el => el === document.activeElement), true);
    await keyboard.keyboard.press('Enter');
    assert.equal(await keyboard.evaluate(() => document.activeElement.id), 'exhibition');
    await keyboard.locator('.hero-art').focus();
    await keyboard.keyboard.press('Enter');
    assert.equal(await keyboard.locator('#art-dialog').isVisible(), true);
    pass('Keyboard-only skip link and artwork opening with Enter');
    assert.deepEqual(errors, []);
    assert.deepEqual(badResponses, []);
    assert.deepEqual(external, []);
    pass('10. No browser errors, HTTP errors or external requests observed');
  } catch (error) {
    results.push({ name: 'Test execution', result: 'FAIL', details: error.stack });
    await page.screenshot({ path: 'artifacts/failure.png' });
    process.exitCode = 1;
  } finally {
    fs.writeFileSync('artifacts/browser-results.json', JSON.stringify({ run: new Date().toISOString(), browser: await browser.version(), results, errors, badResponses, external }, null, 2));
    console.log(JSON.stringify(results, null, 2));
    await browser.close();
  }
})();
