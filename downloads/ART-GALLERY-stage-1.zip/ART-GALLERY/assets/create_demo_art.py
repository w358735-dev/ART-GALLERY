"""Recreate the eight original demo compositions. Python stdlib only; no downloads."""
from pathlib import Path
from math import sin, cos, pi

OUT = Path(__file__).resolve().parent / 'art'
OUT.mkdir(exist_ok=True)

def save(name, title, content, portrait=False, background='#e4d2ad'):
    w, h = (600, 740) if portrait else (800, 640)
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title">
<title id="title">{title} — оригинальная демонстрационная SVG-композиция</title>
<defs>
 <linearGradient id="sky" x2=".25" y2="1"><stop stop-color="{background}"/><stop offset="1" stop-color="#efe0b8"/></linearGradient>
 <linearGradient id="sun" x2="0" y2="1"><stop stop-color="#f8db91"/><stop offset="1" stop-color="#d99b4e"/></linearGradient>
 <linearGradient id="leaf" x2="1" y2="1"><stop stop-color="#739078"/><stop offset="1" stop-color="#305849"/></linearGradient>
 <pattern id="grain" width="9" height="9" patternUnits="userSpaceOnUse"><path d="M1 2h1M6 6h1M3 8h.5" stroke="#172920" stroke-opacity=".13" stroke-width=".7"/></pattern>
</defs>
<g><path fill="{background}" d="M0 0h{w}v{h}H0z"/>{content}<path fill="url(#grain)" d="M0 0h{w}v{h}H0z"/></g></svg>'''
    (OUT / name).write_text(svg, encoding='utf-8')

save('01-light.svg', 'Там, где свет', '''
<path fill="url(#sky)" d="M0 0h800v640H0z"/>
<circle cx="552" cy="181" r="91" fill="url(#sun)"/>
<path d="M0 294Q110 193 245 264T495 285T800 221V640H0" fill="#a4ac86"/>
<path d="M0 365Q135 225 315 326T590 295T800 348V640H0" fill="#748970"/>
<path d="M0 400Q174 359 320 390T540 373T800 399V640H0" fill="#395f50"/>
<path d="M0 460Q154 368 336 449T652 431T800 407V640H0" fill="#284e43"/>
<path d="M458 339C366 399 544 407 470 452S249 482 322 544S495 607 462 640H638C678 553 470 546 446 515S602 454 534 401S430 379 474 340" fill="#d8d6b4"/>
<path d="M0 553Q172 446 292 549T490 640H0" fill="#213e36"/>
<path d="M800 470Q694 436 611 531T552 640H800" fill="#41604a"/>
<g stroke="#b0b37e" stroke-width="2" opacity=".4"><path d="M52 571l-5-42m8 42 9-24M86 554l9-25m-8 20-10-28M707 548l9-39m-6 25-12-18M729 571l-2-32"/></g>
<path d="M78 126q14-13 28 0q14-13 28 0M136 151q10-10 20 0q10-10 20 0" fill="none" stroke="#7e896b" stroke-width="2"/>
''')

houses = ''
for x,y,w,h,color,roof in [(15,350,114,260,'#617580','#8f5f51'),(128,290,103,340,'#788892','#ad765e'),(233,389,119,250,'#4b687c','#be9173'),(357,331,93,309,'#a3a7a0','#6f4f50'),(455,267,116,373,'#4c6980','#a97862')]:
    houses += f'<path d="M{x} {y}h{w}v{h}h-{w}z" fill="{color}"/><path d="M{x-12} {y}l{w/2+12} -68l{w/2+12} 68z" fill="{roof}"/>'
    for xx in range(x+19, x+w-14, 35):
        for yy in range(y+27,y+h-20,62):
            houses += f'<path d="M{xx} {yy}h14v23h-14z" fill="#edce90" opacity=".85"/><path d="M{xx+7} {yy}v23" stroke="{color}" stroke-width="2"/>'
save('02-blue-hour.svg', 'Синий час', f'''
<path fill="#283e55" d="M0 0h600v740H0z"/><circle cx="440" cy="142" r="54" fill="#eddcb2"/><circle cx="462" cy="125" r="53" fill="#283e55"/>
<g fill="#c4c4b7"><circle cx="90" cy="104" r="2"/><circle cx="195" cy="194" r="2"/><circle cx="302" cy="82" r="2"/><circle cx="526" cy="242" r="2"/><circle cx="357" cy="210" r="1.5"/></g>
<path d="M0 398Q180 246 290 323T600 310V740H0" fill="#344e65"/>{houses}<path d="M0 648L600 603V740H0" fill="#203a4b"/>
<path d="M222 740L335 623L371 620L327 740" fill="#b49e82"/>
<path d="M0 681L600 637M0 707L600 666" stroke="#85908d" opacity=".2"/>
''', True, '#283e55')

save('03-pears.svg', 'Разговор на кухне', '''
<path fill="#9d6e51" d="M0 0h800v640H0z"/><path d="M0 0H800V316Q350 340 0 307Z" fill="#a79473"/>
<path d="M0 375Q270 300 800 362V640H0" fill="#ded0aa"/>
<path d="M0 480Q259 373 800 455M140 640L330 380M505 640L543 393" stroke="#c2b38e" stroke-width="8" fill="none"/>
<ellipse cx="390" cy="458" rx="238" ry="49" fill="#736b4d" opacity=".25"/>
<path d="M250 267C209 258 228 311 205 335C142 398 192 453 244 451C315 448 332 394 289 338C269 310 283 264 250 267Z" fill="#c5a34e"/>
<path d="M249 276Q236 242 260 226" fill="none" stroke="#5c5033" stroke-width="9"/>
<path d="M257 259Q287 225 307 252Q286 277 257 259" fill="#536e48"/>
<path d="M394 222C353 219 369 277 342 312C281 390 334 431 390 432C459 432 476 378 428 313C402 278 426 224 394 222Z" fill="#d7b75d"/>
<path d="M394 229Q387 194 410 182" fill="none" stroke="#5c5033" stroke-width="8"/>
<path d="M513 307C480 310 490 352 470 376C428 435 476 471 519 468C569 464 594 423 548 376C527 356 545 307 513 307Z" fill="#a19d4d"/>
<path d="M514 319L525 283" stroke="#5c5033" stroke-width="7"/>
<g fill="#f1d581" opacity=".5"><ellipse cx="226" cy="382" rx="13" ry="30" transform="rotate(15 226 382)"/><ellipse cx="367" cy="348" rx="14" ry="40" transform="rotate(10 367 348)"/></g>
<path d="M624 384q75-16 64 44q-5 34-58 27" stroke="#ece1c0" stroke-width="15" fill="none"/>
<path d="M562 371H642L632 462Q600 483 573 459Z" fill="#eee5ca"/><ellipse cx="602" cy="372" rx="40" ry="11" fill="#79684b"/>
''')

flowers=''
for x,y,r in [(180,220,35),(420,350,45),(210,500,39),(400,126,28),(118,390,24)]:
    petals=''
    for j in range(7):
        angle=j*2*pi/7
        px,py=x+cos(angle)*r*.72,y+sin(angle)*r*.72
        petals+=f'<ellipse cx="{px:.1f}" cy="{py:.1f}" rx="{r*.64:.1f}" ry="{r*.46:.1f}" transform="rotate({j*360/7:.1f} {px:.1f} {py:.1f})" fill="{"#d5a5a1" if x!=210 else "#ead7b3"}"/>'
    flowers+=petals+f'<circle cx="{x}" cy="{y}" r="{r*.32}" fill="#bc9555"/><circle cx="{x-3}" cy="{y-3}" r="{r*.12}" fill="#e0bd70"/>'
leaves=''
for x,y,a in [(110,160,-35),(310,155,30),(260,330,-40),(486,246,25),(100,560,-30),(350,590,45),(440,480,-40),(290,675,20),(85,305,-15),(520,598,45)]:
    leaves+=f'<g transform="translate({x} {y}) rotate({a})"><path d="M0 60C-80 5-60-80 0-90C65-30 75 10 0 60" fill="url(#leaf)"/><path d="M0 55V-70M0 0L-32-33M0-22L24-43" stroke="#96a37a" stroke-width="1.5" opacity=".6"/></g>'
save('04-garden.svg', 'Сад после дождя', f'<path d="M170 740Q330 390 180 190M295 740Q270 420 425 350M330 740Q480 390 400 100" fill="none" stroke="#6e8664" stroke-width="5"/>{leaves}{flowers}<g fill="#d8e3c9" opacity=".7"><ellipse cx="271" cy="338" rx="3" ry="5"/><ellipse cx="431" cy="477" rx="3" ry="5"/><ellipse cx="112" cy="159" rx="3" ry="5"/></g>', True, '#203f38')

save('05-sea.svg', 'Море внутри', '''
<path fill="#b6c6b4" d="M0 0h800v640H0z"/><circle cx="201" cy="149" r="66" fill="#f1dfad"/>
<path d="M0 263Q180 245 377 260T800 253V640H0" fill="#769e98"/>
<path d="M0 348Q200 319 400 350T800 331V640H0" fill="#4b8783"/>
<path d="M0 416Q150 389 399 416T800 408V640H0" fill="#316c6c"/>
<path d="M0 506Q210 466 450 493T800 473V640H0" fill="#235354"/>
<g fill="none" stroke="#a9c3b0" stroke-width="2" opacity=".6"><path d="M50 325h100m28 0h45m-29 49h105m158-84h140M75 457h103m22 0h47m331-76h142M396 552h148m-415 30h90m393-52h85"/></g>
<path d="M470 371L576 371L553 394H492Z" fill="#273c3a"/><path d="M524 265V373" stroke="#555e4a" stroke-width="4"/>
<path d="M517 269L517 358L462 358Z" fill="#f4e8cc"/><path d="M531 289L566 358H531Z" fill="#d5c8a9"/>
<path d="M490 406Q528 415 564 404M500 418H551" stroke="#b5c2a5" stroke-width="2" fill="none"/>
<path d="M0 601Q172 551 348 616T800 583V640H0" fill="#d1c59d"/>
''')

save('06-window.svg', 'Окно в воскресенье', '''
<path d="M0 0h600v740H0z" fill="#b17f60"/><path d="M90 560V255A210 210 0 0 1 510 255V560Z" fill="#6c6652"/>
<path d="M111 540V255A189 189 0 0 1 489 255V540Z" fill="#d3d3b3"/>
<circle cx="375" cy="214" r="53" fill="#edcd86"/>
<path d="M112 394Q204 295 300 374T489 347V540H112" fill="#869c7f"/>
<path d="M112 440Q280 341 489 438V540H112" fill="#4f775e"/>
<path d="M112 492Q329 411 489 491V540H112" fill="#385b49"/>
<path d="M291 68H308V549H291Z" fill="#d6c49e"/><path d="M110 305H490V320H110Z" fill="#d6c49e"/>
<path d="M70 549H530V574H70Z" fill="#e3cba3"/><path d="M80 574L520 574L369 740H0Z" fill="#d5a975" opacity=".55"/>
<path d="M258 558H370L353 654Q317 669 279 651Z" fill="#855841"/>
<path d="M312 568Q283 490 323 418M311 521Q357 476 374 422M311 543Q262 524 242 472" fill="none" stroke="#3c5540" stroke-width="5"/>
<g fill="#516d48"><ellipse cx="311" cy="445" rx="15" ry="35" transform="rotate(30 311 445)"/><ellipse cx="350" cy="479" rx="15" ry="31" transform="rotate(55 350 479)"/><ellipse cx="267" cy="513" rx="14" ry="32" transform="rotate(-55 267 513)"/><ellipse cx="374" cy="429" rx="11" ry="27" transform="rotate(26 374 429)"/></g>
''', True)

trees=''
for x,y,r,color in [(65,235,100,'#9c643e'),(202,173,115,'#c29344'),(357,225,80,'#a45d3d'),(670,201,132,'#b27c3e'),(523,259,84,'#c29c50'),(760,300,94,'#8d6640')]:
    trees+=f'<path d="M{x} 565L{x+6} {y-20}M{x+3} {y+120}l-35-70M{x+3} {y+80}l40-65" stroke="#4e4c36" stroke-width="9" fill="none"/><ellipse cx="{x}" cy="{y}" rx="{r*.77}" ry="{r}" fill="{color}"/><ellipse cx="{x-r*.3}" cy="{y+r*.15}" rx="{r*.62}" ry="{r*.74}" fill="{color}"/>'
save('07-autumn.svg', 'Карманная осень', f'''
<path fill="#b6b492" d="M0 0h800v640H0z"/><path d="M0 341Q140 283 350 337T800 299V640H0" fill="#7a8b66"/>
<path d="M0 445Q260 381 480 420T800 402V640H0" fill="#576f4c"/>{trees}
<path d="M416 370C347 420 495 435 431 481S310 550 279 640H542C481 569 517 542 499 507S409 452 449 420S422 390 437 370" fill="#ceaf78"/>
<path d="M0 572Q120 483 301 536L275 640H0M800 524Q639 474 506 567L545 640H800" fill="#3f5841"/>
<g fill="#d0a15b"><ellipse cx="102" cy="583" rx="11" ry="4" transform="rotate(25 102 583)"/><ellipse cx="370" cy="569" rx="9" ry="4"/><ellipse cx="474" cy="522" rx="7" ry="3"/><ellipse cx="629" cy="580" rx="11" ry="4" transform="rotate(-25 629 580)"/></g>
''')

stars=''.join(f'<path d="M{x-4} {y}h8M{x} {y-4}v8" stroke="#efdec0" stroke-width="1.5"/>' for x,y in [(100,80),(238,154),(374,85),(690,110),(570,235),(130,276),(302,250),(725,278)])
save('08-dream.svg', 'Пока спят облака', f'''
<path fill="#696780" d="M0 0h800v640H0z"/><circle cx="544" cy="136" r="67" fill="#eee0bc"/><circle cx="572" cy="117" r="66" fill="#696780"/>{stars}
<path d="M0 380Q172 264 362 373T800 340V640H0" fill="#b59caa"/>
<path d="M0 461Q188 344 381 460T800 429V640H0" fill="#907e96"/>
<path d="M0 534Q154 428 367 525T800 490V640H0" fill="#5d607b"/>
<path d="M0 605Q268 498 431 604T800 550V640H0" fill="#414c66"/>
<path d="M275 375H384V464H275Z" fill="#e7d7bb"/><path d="M258 378L331 318L401 378Z" fill="#544d69"/>
<path d="M315 409H342V464H315Z" fill="#89708a"/><path d="M351 396H373V424H351Z" fill="#f1d48c"/><path d="M286 396H305V424H286Z" fill="#f1d48c"/>
<path d="M330 464C280 503 429 514 423 568" stroke="#c4a7ad" stroke-width="17" fill="none"/>
<g fill="#d3c3cc" opacity=".65"><path d="M34 203Q48 183 64 194Q82 166 101 191Q128 177 137 203Z"/><path d="M632 327Q646 307 662 318Q680 290 699 315Q726 301 735 327Z"/></g>
''')
print('Created 8 original SVG illustrations.')
