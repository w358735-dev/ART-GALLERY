(() => {
  'use strict';
  const artworks = window.ARTWORKS;
  const root = document.documentElement;
  const gallery = document.querySelector('#artworks');
  const navigation = document.querySelector('.art-navigation');
  const dialog = document.querySelector('#art-dialog');
  const motionButton = document.querySelector('.motion-toggle');
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  let motionOverride = null;
  let current = 0;
  let opener = null;
  let framePending = false;
  const pad = number => String(number).padStart(2, '0');
  const textElement = (tag, className, text) => {
    const element = document.createElement(tag);
    if (className) element.className = className;
    element.textContent = text;
    return element;
  };

  // Text from the editable catalogue is inserted as text, never HTML.
  artworks.forEach((art, index) => {
    const stage = document.createElement('section');
    stage.id = `work-${art.id}`;
    stage.className = `art-stage${[1, 3, 5].includes(index) ? ' portrait' : ''}`;
    stage.setAttribute('aria-labelledby', `title-${art.id}`);
    stage.style.setProperty('--art-color', art.color);
    const scene = textElement('div', 'art-scene', '');
    const painting = textElement('div', 'painting-wrap', '');
    const button = textElement('button', 'painting-button', '');
    button.type = 'button';
    button.dataset.art = index;
    button.setAttribute('aria-label', `Рассмотреть картину «${art.title}»`);
    const frame = textElement('span', 'frame', '');
    const image = new Image();
    image.src = art.image;
    image.alt = art.alt;
    image.width = [1, 3, 5].includes(index) ? 600 : 800;
    image.height = [1, 3, 5].includes(index) ? 740 : 640;
    image.loading = 'lazy';
    image.decoding = 'async';
    frame.append(image);
    button.append(frame);
    painting.append(button);
    const caption = textElement('div', 'painting-caption', '');
    caption.append(textElement('span', '', `${pad(index + 1)} / 08`), textElement('span', '', 'Коллекция воображения'));
    painting.append(caption);
    const info = textElement('div', 'art-info', '');
    const title = textElement('h3', '', art.title);
    title.id = `title-${art.id}`;
    const details = textElement('button', 'text-link', 'Рассмотреть работу');
    details.type = 'button';
    details.dataset.art = index;
    details.setAttribute('aria-label', `Подробнее о картине «${art.title}»`);
    const arrow = textElement('span', 'arrow-up-right', '');
    arrow.setAttribute('aria-hidden', 'true');
    details.append(arrow);
    info.append(textElement('p', 'eyebrow', art.theme), title, textElement('p', 'art-story', art.story), textElement('p', 'art-medium', art.medium), details);
    scene.append(painting, info, textElement('span', 'scene-number', `${pad(index + 1)} — 08`));
    stage.append(scene);
    gallery.append(stage);
    const link = textElement('a', '', pad(index + 1));
    link.href = `#${stage.id}`;
    link.setAttribute('aria-label', `${index + 1}. ${art.title}`);
    navigation.append(link);
  });

  const stages = [...document.querySelectorAll('.art-stage')];
  const navLinks = [...navigation.querySelectorAll('a')];
  const paintings = stages.map(stage => stage.querySelector('.painting-wrap'));
  const reducedMotion = () => motionPreference.matches || Boolean(motionOverride);
  let activeIndex = -1;
  function renderScroll() {
    framePending = false;
    const height = window.innerHeight;
    let nearest = 0;
    let nearestDistance = Infinity;
    // Read geometry first; write transforms afterwards to avoid layout thrashing.
    const bounds = stages.map(stage => stage.getBoundingClientRect());
    const values = bounds.map((rect, index) => {
      const distance = Math.abs(rect.top + rect.height / 2 - height / 2);
      if (distance < nearestDistance) { nearestDistance = distance; nearest = index; }
      if (rect.bottom < -height / 2 || rect.top > height * 1.5) return null;
      const approach = Math.max(0, Math.min(1, (height - rect.top) / (height * 1.05)));
      return { z: -190 * (1 - approach), y: 30 * (1 - approach), rotation: (index % 2 ? -7 : 7) * (1 - approach), opacity: .55 + .45 * approach };
    });
    if (nearest !== activeIndex) {
      navLinks.forEach((link, index) => {
        if (index === nearest) link.setAttribute('aria-current', 'true');
        else link.removeAttribute('aria-current');
      });
      activeIndex = nearest;
    }
    if (!reducedMotion()) values.forEach((value, index) => {
      if (!value) return;
      const style = paintings[index].style;
      style.setProperty('--art-z', `${value.z.toFixed(1)}px`);
      style.setProperty('--art-y', `${value.y.toFixed(1)}px`);
      style.setProperty('--art-rotate', `${value.rotation.toFixed(2)}deg`);
      style.setProperty('--art-opacity', value.opacity.toFixed(3));
    });
  }
  function scheduleScroll() {
    if (!framePending) { framePending = true; requestAnimationFrame(renderScroll); }
  }
  function updateMotion() {
    const reduced = reducedMotion();
    root.classList.toggle('motion-reduced', reduced);
    motionButton.setAttribute('aria-pressed', String(reduced));
    motionButton.disabled = motionPreference.matches;
    motionButton.title = motionPreference.matches ? 'Движение отключено в настройках вашей системы' : 'Настройка анимации галереи';
    motionButton.firstChild.textContent = motionPreference.matches ? 'Движение отключено системой ' : reduced ? 'Движение уменьшено ' : 'Уменьшить движение ';
    scheduleScroll();
  }
  motionButton.addEventListener('click', () => { motionOverride = !reducedMotion(); updateMotion(); });
  motionPreference.addEventListener('change', () => { motionOverride = null; updateMotion(); });
  window.addEventListener('scroll', scheduleScroll, { passive: true });
  window.addEventListener('resize', scheduleScroll, { passive: true });
  updateMotion();

  function showArtwork(index) {
    current = (index + artworks.length) % artworks.length;
    const art = artworks[current];
    const image = document.querySelector('#dialog-image');
    image.src = art.image;
    image.alt = art.alt;
    document.querySelector('#dialog-title').textContent = art.title;
    document.querySelector('#dialog-medium').textContent = art.medium;
    document.querySelector('#dialog-size').textContent = art.size;
    document.querySelector('#dialog-status').textContent = art.status;
    document.querySelector('#dialog-story').textContent = art.story;
    document.querySelector('#dialog-index').textContent = `${pad(current + 1)} / 08 · ${art.theme}`;
    document.querySelector('#dialog-counter').textContent = `${pad(current + 1)} / 08`;
    document.querySelector('#purchase-message').hidden = true;
    dialog.scrollTop = 0;
  }
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-art]');
    if (!button) return;
    opener = button;
    showArtwork(Number(button.dataset.art));
    dialog.showModal();
    document.body.classList.add('modal-open');
  });
  document.querySelector('.close-dialog').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener('close', () => {
    document.body.classList.remove('modal-open');
    opener?.focus({ preventScroll: true });
  });
  document.querySelector('.previous-art').addEventListener('click', () => showArtwork(current - 1));
  document.querySelector('.next-art').addEventListener('click', () => showArtwork(current + 1));
  dialog.addEventListener('keydown', event => {
    if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
      event.preventDefault();
      showArtwork(current + (event.key === 'ArrowRight' ? 1 : -1));
    }
  });
  document.querySelector('.purchase-button').addEventListener('click', () => {
    document.querySelector('#purchase-message').hidden = false;
  });
  document.querySelector('#enter-gallery').addEventListener('click', () => {
    // Move keyboard focus without overriding native anchor navigation.
    document.querySelector('#exhibition').focus({ preventScroll: true });
  });
})();
